# ProjectOne
Project 1 - TollTally app

TollTally is an application coded in JavaScript and jQuery that uses APIs for its funcionality. 

TollTally allows the user to calculate and predict routinely transportation expenses within the Dallas-Fort Worth area. 

Get a hold of your finances by getting the big picture of your commute costs. While you work hard for your money, you can leave the guesswork of you toll expenditures to TollTally!

https://nanzycharris.github.io/ProjectOne/.
